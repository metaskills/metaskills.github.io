class Article < ActiveRecord::Base
  
  has_many :comments
  belongs_to :user
  
  def cache_key
    "#{super}/#{user_id}"
  end
  
end