module ArticleHelper
end
