class ArticlesController < ApplicationController
  
  def index
    @articles = Article.all(:limit => 50, :offset => 50)
  end

end


