require 'test_helper'

class ArticleHelperTest < ActionView::TestCase
end
