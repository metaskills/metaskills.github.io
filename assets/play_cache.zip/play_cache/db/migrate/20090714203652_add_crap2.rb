class AddCrap2 < ActiveRecord::Migration
  
  def self.up
    ken = User.create! :name => 'Ken', :email => 'ken@metaskills.net', :password => 'password'
    ted = User.create! :name => 'Ted', :email => 'ted@foo.com', :password => 'secret'
    100.times do |n|
      ka = ken.articles.create! :title => "Ken's Article ##{n}", :body => "Some body string for article #{n}. "*20
      ta = ted.articles.create! :title => "Ted's Article ##{n}", :body => "Some body string for article #{n}. "*20
      10.times do |cn|
        ka.comments.create! :title => "Comment #{cn}", :body => 'Comment body comment body comment body.'
        ta.comments.create! :title => "Comment #{cn}", :body => 'Comment body comment body comment body.'
      end
    end
  end

  def self.down
  end
  
end
