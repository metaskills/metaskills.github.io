class AddCrap < ActiveRecord::Migration
  
  def self.up
    create_table :users, :force => true do |t|
      t.string  :name, :email, :password
      t.timestamps
    end
    create_table :articles, :force => true do |t|
      t.string  :title, :body
      t.integer :user_id
      t.timestamps
    end
    create_table :comments, :force => true do |t|
      t.string  :title, :body
      t.integer :article_id
      t.timestamps
    end
  end

  def self.down
    drop_table :comments
    drop_table :articles
    drop_table :users
  end
  
end
